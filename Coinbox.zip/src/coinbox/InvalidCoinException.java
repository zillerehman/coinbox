package coinbox;
public class InvalidCoinException
   extends Exception
{
   public InvalidCoinException()
   { super ("Invalid Coin"); }
}
