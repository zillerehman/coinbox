package coinbox;
public class UnknownItemException
   extends Exception
{  public UnknownItemException()
   { super ("Unknown Item"); }
}
