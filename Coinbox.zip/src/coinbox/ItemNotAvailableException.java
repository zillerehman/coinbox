package coinbox;
public class ItemNotAvailableException
   extends Exception
{ public ItemNotAvailableException()
  { super ("Item Not Available"); }
}
