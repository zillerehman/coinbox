package coinbox;
public class InvalidPriceException
   extends Exception
{
   public InvalidPriceException()
   { super ("Invalid Price"); }
}
